package com.example.devicecare

import android.app.Activity
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var monitor: UsbDeviceMonitor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        val usbManager = getSystemService(USB_SERVICE) as UsbManager
        monitor = UsbDeviceMonitor(usbManager)
        findViewById<Button>(R.id.scanButton).setOnClickListener { scan() }
        scan()
    }

    private fun scan() {
        val devices = monitor.describe()
        output.text = if (devices.isEmpty()) {
            "Nenhum dispositivo USB encontrado.\n\nConecte o aparelho usando um adaptador USB-OTG e toque novamente."
        } else {
            devices.joinToString("\n------------------------------\n")
        }
    }
}
