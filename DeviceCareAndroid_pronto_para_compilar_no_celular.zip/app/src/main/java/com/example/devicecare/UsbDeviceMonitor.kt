package com.example.devicecare

import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager

class UsbDeviceMonitor(private val usbManager: UsbManager) {
    fun describe(): List<String> = usbManager.deviceList.values.map { device ->
        val interfaces = (0 until device.interfaceCount).map { i ->
            val intf = device.getInterface(i)
            "  interface $i: class=${intf.interfaceClass} subclass=${intf.interfaceSubclass} protocol=${intf.interfaceProtocol}"
        }
        buildString {
            appendLine("${device.manufacturerName ?: "USB"} ${device.productName ?: "dispositivo"}")
            appendLine("  vendorId=${device.vendorId} productId=${device.productId}")
            appendLine("  serial=${device.serialNumber ?: "indisponível"}")
            appendLine("  ADB-like interface=${device.hasAdbInterface()}")
            interfaces.forEach(::append)
        }
    }

    private fun UsbDevice.hasAdbInterface(): Boolean = (0 until interfaceCount).any { i ->
        val intf = getInterface(i)
        intf.interfaceClass == 0xFF && intf.interfaceSubclass == 0x42 && intf.interfaceProtocol == 0x01
    }
}
