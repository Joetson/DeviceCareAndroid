plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.example.devicecare"; compileSdk = 36
    defaultConfig { applicationId = "com.example.devicecare"; minSdk = 26; targetSdk = 36; versionCode = 1; versionName = "1.0.0" }
}

kotlin { jvmToolchain(17) }
