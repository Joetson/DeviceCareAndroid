# Como gerar o APK usando somente o celular

1. Crie uma conta no GitHub em github.com.
2. Crie um repositório novo, por exemplo `DeviceCareAndroid`.
3. No celular, abra o repositório e use **Add file > Upload files**.
4. Descompacte este ZIP no celular e envie os arquivos e pastas do projeto para o repositório.
   - A pasta `.github/workflows` também precisa ser enviada.
5. Depois do upload, abra **Actions** no GitHub.
6. O workflow **Build APK** será executado automaticamente.
7. Quando terminar, abra a execução concluída e procure a seção **Artifacts**.
8. Baixe `DeviceCare-debug-apk.zip`.
9. Dentro dele estará `app-debug.apk`.
10. Toque no APK para instalar. Se o Android pedir, permita a instalação de apps dessa fonte.

Observação: este projeto é para diagnóstico/manutenção autorizada e não contém rotinas de bypass ou remoção de FRP.
