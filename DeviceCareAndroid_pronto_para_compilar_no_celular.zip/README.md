# Device Care Android

Base Android inspirada na estrutura do programa enviado, destinada a diagnóstico e manutenção autorizada de aparelhos.

## O que já existe
- Projeto Android/Kotlin pronto para abrir no Android Studio.
- Detecção de dispositivos USB via USB Host/OTG.
- Leitura de fabricante, produto, VID/PID, serial quando o Android permitir e descritores de interfaces.
- Identificação preliminar de uma interface compatível com o protocolo ADB.
- Recepção de conexão USB pelo intent `USB_DEVICE_ATTACHED`.

## Próximas etapas seguras
1. Implementar uma camada ADB USB com autenticação normal.
2. Tela de informações do aparelho quando a depuração USB estiver autorizada.
3. Diagnósticos de conectividade, armazenamento, bateria e versão do sistema.
4. Operações de manutenção que não contornem bloqueios de segurança.

## Limite de segurança
As rotinas de bypass/remoção de FRP, desbloqueio de conta ou contorno de mecanismos de segurança não fazem parte deste projeto.

## Build
Abra a pasta no Android Studio recente e execute `assembleDebug`. O projeto usa Android Gradle Plugin 8.13 e Kotlin 2.2.20, com Java 17.
